/*
 * File:   newmain1.c
 * Author: szita
 *
 * Created on 2016. december 25., 11:27
 */

// CONFIG
#pragma config OSC = IntRC      // Oscillator Select (INTOSC with 1.125 ms DRT)
#pragma config WDT = OFF        // Watchdog Timer Enable bit (WDT disabled)
#pragma config CP = OFF         // Code Protect (Code protection off)
#pragma config MCLRE = ON       // Master Clear Enable bit (GP3/MCLR Functions as MCLR)
#pragma config IOSCFS = ON      // Internal Oscillator Frequency Select bit (8 MHz INTOSC Speed)

#include <xc.h>
#include <stdint.h>
#include <stdbool.h>

#define _XTAL_FREQ  8000000

//ADC BEOLVASA----------------------------------
//----------------------------------------------
unsigned char adc_read(unsigned char chanel)
{
unsigned char ad_in;
   
ADCON0=chanel;
GO=1;	
while(GO==1)
	{
	}
ad_in=ADRES;

return ad_in;
}

void main(void) {
    
    TRISGPIO=31;
    OPTION=192;
    CM1CON0=0;
    ADCON0=0;

    
    while(1)
    {
        GP5=1;
            if (GP2==1)
            __delay_us(1800);
            else
            __delay_us(1000);        
        GP5=0;
        __delay_ms(15);
    }
    return;
}
